#!/bin/bash
#
# ©2021 Copyright 2021 Robert D. Chin
# Email: RDevChin@Gmail.com
#
# Usage: bash cliappmenu.sh
#        (not sh cliappmenu.sh)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <https://www.gnu.org/licenses/>.
#
# +----------------------------------------+
# |        Default Variable Values         |
# +----------------------------------------+
#
VERSION="2021-07-01 11:28"
#
# Set THIS_FILE to the name of this script file.
THIS_FILE=$(basename $0)
#
TEMP_FILE=$THIS_FILE"_temp.txt"
TEMP_FILE_2=$THIS_FILE"_temp_2.txt"
TEMP_FILE_3=$THIS_FILE"_temp_3.txt"
#
# +----------------------------------------+
# |            Brief Description           |
# +----------------------------------------+
#
#& Brief Description
#& This script searches cliappmenu project for libraries which contain
#& forbidden characters which will corrupt the menu displays because the menus
#& depend on arrays to display the menu options. The characters will corrupt
#& the arrays. Forbidden characters include ; : * ' " > < &
#& Forbidden characters include semi-colons, colons, asterisks, single-quotes,
#& double-quotes, greater-than and less-than signs, and ampersands.
#&
#& Accepted characters include dashes
#
#
# +----------------------------------------+
# |          f_grep_forbidden_chars        |
# +----------------------------------------+
#
f_grep_forbidden_chars () {
      #
      # Get menu item data. grep -h prevents the printing of the file name before the results.
      grep  "#@@" apps_*.lib > $TEMP_FILE
      # Get file name.
      awk -F ":" '{ print $1 }' $TEMP_FILE > $TEMP_FILE_2
      # Get data string.
      awk -F ":" '{ print $2 }' $TEMP_FILE > $TEMP_FILE_3
      # Get app name and description from data string.
      awk -F "#@@" '{ print$2"#@@"$3 }' $TEMP_FILE_3 > $TEMP_FILE
      #
      grep ";" $TEMP_FILE > $TEMP_FILE_3
      grep ":" $TEMP_FILE >> $TEMP_FILE_3
      grep "*" $TEMP_FILE >> $TEMP_FILE_3
      grep "'" $TEMP_FILE >> $TEMP_FILE_3
      grep ">" $TEMP_FILE >> $TEMP_FILE_3
      grep "<" $TEMP_FILE >> $TEMP_FILE_3
      grep "&" $TEMP_FILE >> $TEMP_FILE_3
      #grep -e "[\"]"  $TEMP_FILE_>> $TEMP_FILE_3
      #
} # End of function f_grep_forbidden_chars.
#
# +----------------------------------------+
# |      f_add_forbidden_chars_warning     |
# +----------------------------------------+
#
f_add_forbidden_chars_warning () {
      #
      # Create file message_warning_forbidden_characters.txt.
      while read LINE
            do
               # Display text (all lines beginning ("^") with $2 but do not print $2).
               # sed substitutes null for $2 at the beginning of each line
               # so it is not printed.
               sed -n "s/#://"p $THIS_FILE >> message_warning_forbidden_characters.txt
            done < $THIS_FILE
      #
      # Create list of app menu files.
      #ls apps_* > $TEMP_FILE
      #
      #while read FILE
      #      do
      #          while read LINE
      #               do
      #                  sed -i "/#@@Return#@@Return to previous menu.#@@break/i $LINE" $FILE
      #               done < message_warning_forbidden_characters.txt
      #      done < $TEMP_FILE
      #
      #:
      #:    Category Menu Format: <#@@> <Menu Option> <#@@> <Description of Menu Option> <#@@> <Corresponding function or action or cammand>^arg1
      #: Application Menu Format: <#@@> <Menu Option> <#@@> <Description of Menu Option> <#@@> <Corresponding function or action or cammand>^arg1^arg2^arg3^arg4^arg5
      #:
      #:
      #:                 >>> !!!Warning!!! <<<
      #:
      #: The Menu Item Descriptions cannot have semi-colons, colons, asterisks, 
      #: single-quotes, double-quotes, ampersands, greater-than and less-than signs.
      #:
      #: Forbidden characters include ; : * ' " & > < 
      #:
      #: These characters will compromise the creation of arrays which
      #: in turn creates the menu.
      #:
      #
} # End of function f_add_forbidden_chars_warning.
#
# +----------------------------------------+
# |         f_add_reset_text_colors        |
# +----------------------------------------+
#
f_add_reset_text_colors () {
      #
      # Find all files containing "f_message" and "$TEMP_FILE" on a line.
      grep 'f_message $1 "OK".*$TEMP_FILE' apps_* > $TEMP_FILE
      grep 'f_message $1 "NOK".*$TEMP_FILE' apps_* >> $TEMP_FILE
      #
      #
} # End of function f_add_reset_text_colors.
#
#
# **************************************
# **************************************
# ***     Start of Main Program      ***
# **************************************
# **************************************
#     Rev: 2021-03-11
#
#f_add_forbidden_chars_warning
f_add_reset_text_colors
