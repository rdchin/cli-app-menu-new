#!/bin/bash
#
# ©2021 Copyright 2021 Robert D. Chin
# Email: RDevChin@Gmail.com
#
# Usage: bash cliappmenu.sh
#        (not sh cliappmenu.sh)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <https://www.gnu.org/licenses/>.
#
# +----------------------------------------+
# |        Default Variable Values         |
# +----------------------------------------+
#
VERSION="2021-07-01 11:28"
#
# Set THIS_FILE to the name of this script file.
THIS_FILE=$(basename $0)
#
THIS_FILE="cliapp_util_date_stamper.sh"
TEMP_FILE=$THIS_FILE"_temp.txt"
#
# +----------------------------------------+
# |            Brief Description           |
# +----------------------------------------+
#
#& Brief Description
#& This script searches cliappmenu project for libraries and scripts and
#& updates the date stamp in each file.
#&
#& It does not update any copyright dates.
#
#
# **************************************
# **************************************
# ***     Start of Main Program      ***
# **************************************
# **************************************
#     Rev: 2021-03-11
#
#
THIS_FILE="cliapp_util_date_stamper.sh"
TEMP_FILE=$THIS_FILE"_temp.txt"
#
# Create list of all files.
ls * > $TEMP_FILE
#
while read FILE
      do
         sed -i 's/VERSION="2021-07-01 11:28"
      done < $TEMP_FILE
#
rm $TEMP_FILE
